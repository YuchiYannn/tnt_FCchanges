function [ VecFiles ] = findfiles( InputDir,ext,IsReturnNameOnly )
%% Find the files that contain given character strings.
%
% ---------------------------------------------------------------------------------------------------%
%% Input
%  (1) InputDir: the path to be retrieved
%  (2) ext: specific character strings (e.g., '.m')
%  (3) IsReturnNameOnly: if only return the file names 
%                        (1 = only return the file names; 0 = return the path name & file names )
% ---------------------------------------------------------------------------------------------------%
%% Output
%  (1) VecFiles: files with specific character strings
% ---------------------------------------------------------------------------------------------------%

if ~isdir(InputDir)
    msgbox('The input isnot a valid directory','Warning','warn');
    return 
else
    if nargin == 1
        ext = '*';
        IsReturnNameOnly = 1;
    elseif nargin == 2
        IsReturnNameOnly = 1;
    elseif nargin>3||nargin<1
        msgbox('1 or 2 inputs are required','Warning','warn');
        return
    end
    if nargout>1
        msgbox('Too many output arguments','Warning','warn');
        return
    end
end
    filesname = {};
    strtmp = strcat(InputDir,'\*',ext);
    files = dir(strtmp);
    m = length(files);
    num = 0;
    for i =1:1:m
        if ~(strcmp(files(i).name,'.')||strcmp(files(i).name,'..'))
            tmp = files(i).name;  
            if ~files(i).isdir        
                num = num + 1;
                if IsReturnNameOnly    
                    filesname{num} = tmp;
                else                   
                    tmp = fullfile(InputDir,tmp);
                    filesname{num} = tmp;
                end
            end
        end
    end
    if nargout==1
        VecFiles = filesname';
    end
end